=== Themovation Bootstrap 3 Shortcodes ===
Contributors: themovation
Tags: Bootstrap 3, Bootstrap, Shortcodes
Requires at least: 4.1
Tested up to: 4.1
License: Regular
License URI: http://themeforest.net/licenses

This is a plugin for WordPress that adds shortcodes for easier use of the Bootstrap 3 elements in your content.

== Description ==
Bootstrap 3 Shortcodes for WordPress requires that you have Bootstrap 3 installed. It includes a shortcode generator. 

== Installation ==
1. Download and unzip this plugin
2. Upload the \"bellevue-shortcodes\" folder to your site\'s /wp-content/plugins/ directory
3. Activate the plugin through the \'Plugins\' menu in WordPress
4. Create or edit a page or post and click the shortocde button that appears above the editor and start adding shortcodes